const mysql = require("mysql2/promise");

const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "STmysql!7124",
    database: "inventory_system",
    waitForConnections: true,
    connectionLimit: 10
});

module.exports = pool;