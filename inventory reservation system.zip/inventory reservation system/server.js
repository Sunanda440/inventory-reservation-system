const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.use("/api/products", require("./routes/products"));
app.use("/api/warehouses", require("./routes/warehouses"));
app.use("/api/reservations", require("./routes/reservations"));

app.listen(5000, () => {
    console.log("Server running on port 5000");
});