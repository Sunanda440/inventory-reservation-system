const express = require("express");
const router = express.Router();

const pool = require("../db");

router.post("/", async (req, res) => {

    const { inventoryId, quantity } = req.body;

    const connection = await pool.getConnection();

    try {

        await connection.beginTransaction();

        const [rows] = await connection.query(
            `
            SELECT *
            FROM inventory
            WHERE id = ?
            FOR UPDATE
            `,
            [inventoryId]
        );

        const inventory = rows[0];

        const available =
            inventory.total_stock - inventory.reserved_stock;

        if (available < quantity) {

            await connection.rollback();

            return res.status(409).json({
                message: "Not enough stock available"
            });
        }

        await connection.query(
            `
            UPDATE inventory
            SET reserved_stock = reserved_stock + ?
            WHERE id = ?
            `,
            [quantity, inventoryId]
        );

        const expiresAt = new Date(
            Date.now() + 10 * 60 * 1000
        );

        const [result] = await connection.query(
            `
            INSERT INTO reservations
            (inventory_id, quantity, status, expires_at)
            VALUES (?, ?, 'PENDING', ?)
            `,
            [inventoryId, quantity, expiresAt]
        );

        await connection.commit();

        res.json({
            reservationId: result.insertId,
            expiresAt
        });

    } catch (err) {

        await connection.rollback();

        res.status(500).json({
            error: err.message
        });

    } finally {

        connection.release();
    }
});

//module.exports = router;
router.post("/:id/confirm", async (req, res) => {

    const reservationId = req.params.id;

    const [rows] = await pool.query(
        `
        SELECT *
        FROM reservations
        WHERE id = ?
        `,
        [reservationId]
    );

    const reservation = rows[0];

    if (!reservation) {

        return res.status(404).json({
            message: "Reservation not found"
        });
    }

    if (
        new Date() >
        new Date(reservation.expires_at)
    ) {

        return res.status(410).json({
            message: "Reservation expired"
        });
    }

    await pool.query(
        `
        UPDATE reservations
        SET status = 'CONFIRMED'
        WHERE id = ?
        `,
        [reservationId]
    );

    res.json({
        message: "Reservation confirmed"
    });
});
router.post("/:id/release", async (req, res) => {

    const reservationId = req.params.id;

    const connection =
        await pool.getConnection();

    try {

        await connection.beginTransaction();

        const [rows] =
            await connection.query(
                `
                SELECT *
                FROM reservations
                WHERE id = ?
                FOR UPDATE
                `,
                [reservationId]
            );

        const reservation = rows[0];

        await connection.query(
            `
            UPDATE inventory
            SET reserved_stock =
            reserved_stock - ?
            WHERE id = ?
            `,
            [
                reservation.quantity,
                reservation.inventory_id
            ]
        );

        await connection.query(
            `
            UPDATE reservations
            SET status = 'RELEASED'
            WHERE id = ?
            `,
            [reservationId]
        );

        await connection.commit();

        res.json({
            message: "Reservation released"
        });

    } catch (err) {

        await connection.rollback();

        res.status(500).json({
            error: err.message
        });

    } finally {

        connection.release();
    }
});
module.exports = router;