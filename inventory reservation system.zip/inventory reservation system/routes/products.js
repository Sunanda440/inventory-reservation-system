const express = require("express");
const router = express.Router();
const pool = require("../db");

router.get("/", async (req, res) => {

    const [rows] = await pool.query(`
        SELECT
            p.id,
            p.name,
            w.name AS warehouse,
            i.total_stock,
            i.reserved_stock,
            (i.total_stock - i.reserved_stock) AS available_stock
        FROM inventory i
        JOIN products p ON p.id = i.product_id
        JOIN warehouses w ON w.id = i.warehouse_id
    `);

    res.json(rows);
});

module.exports = router;