const API_BASE = "http://localhost:5000/api";


// ===========================
// LOAD PRODUCTS
// ===========================

async function loadProducts() {

    const container =
        document.getElementById("products-container");

    if (!container) return;

    try {

        const response = await fetch(
            `${API_BASE}/products`
        );

        const products = await response.json();

        container.innerHTML = "";

        products.forEach(product => {

            const div = document.createElement("div");

            div.className = "product-card";

            div.innerHTML = `
                <h2>${product.name}</h2>

                <p>
                    Warehouse:
                    ${product.warehouse}
                </p>

                <p>
                    Available Stock:
                    ${product.available_stock}
                </p>

                <button onclick="reserveStock(${product.id})">
                    Reserve
                </button>
            `;

            container.appendChild(div);
        });

    } catch (err) {

        console.error(err);
    }
}


// ===========================
// RESERVE STOCK
// ===========================

async function reserveStock(inventoryId) {

    try {

        const response = await fetch(
            `${API_BASE}/reservations`,
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    inventoryId,
                    quantity: 1
                })
            }
        );

        const data = await response.json();

        if (response.status === 409) {

            alert(data.message);

            return;
        }

        localStorage.setItem(
            "reservationId",
            data.reservationId
        );

        localStorage.setItem(
            "expiresAt",
            data.expiresAt
        );

        window.location.href =
            "checkout.html";

    } catch (err) {

        console.error(err);
    }
}


// ===========================
// CHECKOUT PAGE
// ===========================

async function loadReservationPage() {

    const details =
        document.getElementById(
            "reservation-details"
        );

    if (!details) return;

    const reservationId =
        localStorage.getItem("reservationId");

    const expiresAt =
        localStorage.getItem("expiresAt");

    details.innerHTML = `
        <p>
            Reservation ID:
            ${reservationId}
        </p>
    `;

    startTimer(expiresAt);

    document
        .getElementById("confirmBtn")
        .addEventListener("click", confirmReservation);

    document
        .getElementById("cancelBtn")
        .addEventListener("click", releaseReservation);
}


// ===========================
// TIMER
// ===========================

function startTimer(expiresAt) {

    const timer =
        document.getElementById("timer");

    const interval = setInterval(() => {

        const now = new Date().getTime();

        const expiry =
            new Date(expiresAt).getTime();

        const distance = expiry - now;

        if (distance <= 0) {

            clearInterval(interval);

            timer.innerHTML =
                "Reservation Expired";

            return;
        }

        const minutes =
            Math.floor(distance / 60000);

        const seconds =
            Math.floor((distance % 60000) / 1000);

        timer.innerHTML =
            `Time Left: ${minutes}m ${seconds}s`;

    }, 1000);
}


// ===========================
// CONFIRM RESERVATION
// ===========================

async function confirmReservation() {

    const reservationId =
        localStorage.getItem("reservationId");

    try {

        const response = await fetch(
            `${API_BASE}/reservations/${reservationId}/confirm`,
            {
                method: "POST"
            }
        );

        const data = await response.json();

        if (response.status === 410) {

            alert(data.message);

            return;
        }

        alert(data.message);

        window.location.href =
            "index.html";

    } catch (err) {

        console.error(err);
    }
}


// ===========================
// RELEASE RESERVATION
// ===========================

async function releaseReservation() {

    const reservationId =
        localStorage.getItem("reservationId");

    try {

        const response = await fetch(
            `${API_BASE}/reservations/${reservationId}/release`,
            {
                method: "POST"
            }
        );

        const data = await response.json();

        alert(data.message);

        window.location.href =
            "index.html";

    } catch (err) {

        console.error(err);
    }
}


// ===========================
// AUTO LOAD
// ===========================

loadProducts();
loadReservationPage();